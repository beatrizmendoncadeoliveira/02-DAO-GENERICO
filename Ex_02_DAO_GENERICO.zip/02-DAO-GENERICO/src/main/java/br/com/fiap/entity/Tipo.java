package br.com.fiap.entity;

public enum Tipo {

	CREDITO, DEBITO, DINHEIRO;
}
