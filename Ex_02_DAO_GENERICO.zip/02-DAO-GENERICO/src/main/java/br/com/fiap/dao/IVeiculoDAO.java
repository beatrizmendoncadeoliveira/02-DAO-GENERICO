package br.com.fiap.dao;

import br.com.fiap.entity.Veiculo;

public interface IVeiculoDAO extends IGenericDAO<Veiculo, Integer>{

}
