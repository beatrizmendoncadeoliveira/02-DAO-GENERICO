package br.com.fiap.dao;

import br.com.fiap.exception.CommitException;
import br.com.fiap.exception.KeyNotFoundException;

public  abstract class GenericDAOImpl<T,K> implements IGenericDAO<T,K> {

	//private EntityManager em;
	//private class<T> clazz;
	//public GenericDAOImpl(EntityManager em){
	//this.em=em;
	//this.clazz=(Class<T>)((ParametizedType)getClass().getGenericSuperClass()).getActualTypeArguments()[0];       
//}
	public void cadastrar(T entity) {
		//em.persist();
		
	}

	//public T pesquisar(K id) throws KeyNotFoundException {
		//T entity=em.find(clazz, id);
//	}

	public void atualizar(T entity) {
	//	em.merge();
		
	}

	public void apagar(K id) throws KeyNotFoundException {
		//T entity=pesquisar(id);
		//em.remove(entity);
	}

	public void commit() throws CommitException {
	//try{
		//em.getTransition().begin;
		//em.getTransisiton().commit();
	//}catch(Exception e) {
		//e.printStackTrace();
		//em.getTransisiton().rollback();
		
	}

	
}
