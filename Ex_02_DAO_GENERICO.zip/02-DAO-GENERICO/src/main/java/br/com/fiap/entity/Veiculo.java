package br.com.fiap.entity;
//@entity
//@table(name="TB_VEICULO")
public class Veiculo {
	//@id
	//@column(name="cd_veiculo")
	private int id_veiculo;
	
	//@column(name="ds_placa", nullable=false)
	private String placa;
	
	//@column(name="ds_cor", nullable=false)
	private String cor;
	
	//@column(name="nr_ano", nullable=false)
	private int numero;
	
	
}
