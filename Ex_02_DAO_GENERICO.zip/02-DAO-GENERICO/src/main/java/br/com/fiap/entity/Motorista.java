package br.com.fiap.entity;

import java.util.Date;

//@entity
public class Motorista {

	//@id
	//@column(name="nr_carteira", nullable=false)
	private int numero;
	
	//@column(name="nm_motorista", nullable=false)
	private String nome;
	
	//@column(name="dt_nascimento", nullable=false)
	private Date data_nascimento;
	
	//@column(name="fl_carteira", nullalble=false)
	//@blob
	private byte[] foto;
	
	//@column(name="ds_genero", nullable=false)
	private String descricao;
	
	
	
}
