package br.com.fiap.dao;

import br.com.fiap.entity.Veiculo;
import br.com.fiap.exception.KeyNotFoundException;

public class VeiculoDAOImpl extends GenericDAOImpl<Veiculo, Integer>
implements IVeiculoDAO{

		//apagar isso
	public Veiculo pesquisar(Integer id) throws KeyNotFoundException {
		return null;
	
	}
	//public VeiculoDAOImpl(Entity Manager em) {
		//super(em);
	//}

}
