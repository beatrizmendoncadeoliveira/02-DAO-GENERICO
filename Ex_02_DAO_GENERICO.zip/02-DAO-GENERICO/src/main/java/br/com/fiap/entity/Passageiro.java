package br.com.fiap.entity;

import java.util.Date;
//@entity
//SequenceGenerator(name="seq", allocationSize=1, sequenceName="seq_passageiro")
public class Passageiro {
	//@id
	//@GeneratorValue(name="seq", strategy=generatorTypeSEQUENCE)
	//@Column(name="cd_passageiro", nullable=false)
	private int codigo;
	
	//@Column(name="nm_passageiro", nullable=false)
	private String nome;
	
	
	//@Column(name="dt_nascimento", nullable=false)
	private Date data_nascimento;
	
	
	//@Column(name="ds_genero", nullable=false)
	private String genero;
	
	

}
