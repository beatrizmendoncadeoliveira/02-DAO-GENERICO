package br.com.fiap.dao;

import br.com.fiap.entity.Passageiro;

public interface IPassageiroDAO extends IGenericDAO<Passageiro,Integer>{

}
