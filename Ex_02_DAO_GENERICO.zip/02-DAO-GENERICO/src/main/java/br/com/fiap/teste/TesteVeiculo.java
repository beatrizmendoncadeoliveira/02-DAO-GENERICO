package br.com.fiap.teste;

import br.com.fiap.dao.GenericDAOImpl;
import br.com.fiap.dao.IGenericDAO;
import br.com.fiap.entity.Veiculo;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class TesteVeiculo {
	
	public static void main(String[] args) {
		     //  EntityManagerFactory f=EntityManagerFactorySingleton.getInstance();
		       //EntityManager em=f.createEntityManager();
		       //IGenericDAO<Veiculo,Integer> dao=new GenericDAOImpl<Veiculo, Integer>(em){}
		       
		       try {
		    	 //  Veiculo v=new Veiculo;
		    	   //dao.cadastrar(v);
		    	   //dao.commit();
		    	   
		       }catch (Exception e) {
				///f.close();
				//em.close();
			}
	}

}
