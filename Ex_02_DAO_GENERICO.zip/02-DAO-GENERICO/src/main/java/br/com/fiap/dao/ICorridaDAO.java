package br.com.fiap.dao;

import br.com.fiap.entity.Corrida;

public interface ICorridaDAO extends IGenericDAO<Corrida,Integer>{

}
