package br.com.fiap.singleton;

public class EntityManagerFactorySingleton {
	
	public EntityManagerFactorySingleton() {
		
	}
	//private static EntityManagerFactory f;
	//public static EntityManagerFactory getInstance() {
		//if(f==null) {
			//f=Persistence.createEntityManagerFactory("oracle");
		//}
		//return f;
	//}

}
