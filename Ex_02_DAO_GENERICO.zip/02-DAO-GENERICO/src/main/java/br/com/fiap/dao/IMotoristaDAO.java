package br.com.fiap.dao;

import br.com.fiap.entity.Motorista;

public interface IMotoristaDAO extends IGenericDAO<Motorista,Integer>{

}
