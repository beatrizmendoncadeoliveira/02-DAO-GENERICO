package br.com.fiap.dao;

import br.com.fiap.exception.CommitException;
import br.com.fiap.exception.KeyNotFoundException;

public interface IGenericDAO<T,K> {
	
	void cadastrar(T entity);
	
	T pesquisar(K id)throws KeyNotFoundException;
	
	void atualizar(T entity);
	
	void apagar(K id)throws KeyNotFoundException;
	
	void commit()throws CommitException;
}
