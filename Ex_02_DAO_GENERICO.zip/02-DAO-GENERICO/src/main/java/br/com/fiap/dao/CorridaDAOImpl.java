package br.com.fiap.dao;

import br.com.fiap.entity.Corrida;
import br.com.fiap.exception.KeyNotFoundException;

public class CorridaDAOImpl extends GenericDAOImpl<Corrida,Integer> implements ICorridaDAO{

	//public CorridaDAOImpl(EntityManger em){
	//super(em);
//}
	public Corrida pesquisar(Integer id) throws KeyNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
