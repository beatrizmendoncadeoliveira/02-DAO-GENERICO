package br.com.fiap.dao;

import br.com.fiap.entity.Passageiro;
import br.com.fiap.exception.KeyNotFoundException;

public class PassageiroDAOImpl extends GenericDAOImpl<Passageiro, Integer> implements IPassageiroDAO{

	//public PassageiroDAOImpl(EntityManager em) {
		//super(em);
	//}
	public Passageiro pesquisar(Integer id) throws KeyNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
