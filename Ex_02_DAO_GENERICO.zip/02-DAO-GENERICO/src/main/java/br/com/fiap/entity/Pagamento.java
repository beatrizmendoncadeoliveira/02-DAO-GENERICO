package br.com.fiap.entity;

import java.util.Date;

//@entity
//sequenceGenerator(name="seq", sequenceName="seq_pagamento", allocationSize=1)
public class Pagamento {
	//@id
	//@Column(name="cd_pagamento", nullable=false)
	//generatedValue(name="seq",strategy=generatorTypeSEQUENCE)
	private int codigo;
	//@Column(name="dt_pagamento", nullable=false)
	private Date data;
	//@Column(name="vl_pagamento", nullable=false)
	private double valor;
	//@Column(name="ds_forma_pagamento", nullable=false)
	//@Enumerated(enumTypeSTRING)
	private Tipo descricao;
	
}
