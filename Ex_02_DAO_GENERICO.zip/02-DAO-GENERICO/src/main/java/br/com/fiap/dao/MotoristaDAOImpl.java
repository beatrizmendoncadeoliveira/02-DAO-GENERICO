package br.com.fiap.dao;

import br.com.fiap.entity.Motorista;
import br.com.fiap.exception.KeyNotFoundException;

public class MotoristaDAOImpl extends GenericDAOImpl<Motorista, Integer> implements IMotoristaDAO {

	//public MotoristaDAOImpl(EntityManager em) {
		//super(em);
	//}
	public Motorista pesquisar(Integer id) throws KeyNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
