package br.com.fiap.dao;

import br.com.fiap.entity.Pagamento;
import br.com.fiap.exception.KeyNotFoundException;

public class PagamentoDAOImpl extends GenericDAOImpl<Pagamento,Integer> 
									implements IPagamentosDAO{

	
	//public PagamentoDAOImpl(EntityManager em) {
		//super(em);
	//}
	public Pagamento pesquisar(Integer id) throws KeyNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
