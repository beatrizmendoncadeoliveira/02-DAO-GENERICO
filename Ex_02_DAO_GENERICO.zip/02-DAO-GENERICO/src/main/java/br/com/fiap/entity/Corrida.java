package br.com.fiap.entity;

import java.util.Date;
//@entity
//@sequenceGenerator(name="seq", allocationSize=1, sequenceName="seq_corrida")
public class Corrida {
	//@id
	//@GeneratedValue(name="seq", strategy=generatorTypeSEQUENCE)
	//@Column(name="cd_corrida", nullable=false)
	private int codigo;
	
	
	//@Column(name="ds_origem", nullable=false)
	private String origem;
	
	
	//@Column(name="ds_destino", nullable=false)
	private String  destino;
	
	
	//@Column(name="dt_corrida", nullable=false)
	private Date data;
	
	
	//@Column(name="vl_corrida", nullable=false)
	private double valor;
	
	

}
