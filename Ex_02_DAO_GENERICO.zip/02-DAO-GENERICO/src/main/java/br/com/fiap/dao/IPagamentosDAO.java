package br.com.fiap.dao;

import br.com.fiap.entity.Pagamento;

public interface IPagamentosDAO extends IGenericDAO<Pagamento, Integer>{

}
